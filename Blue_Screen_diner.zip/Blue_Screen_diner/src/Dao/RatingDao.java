/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import model.Rating;

/**
 *
 * @author Awsom
 */
public class RatingDao {
    public static void save(Rating rating){
        String query = "insert into rating values('"+rating.getEmail()+"','"+rating.getComment()+"')";
        DbOperations.setDataOrDelete(query, "Rating Added Successfully");
    }
}

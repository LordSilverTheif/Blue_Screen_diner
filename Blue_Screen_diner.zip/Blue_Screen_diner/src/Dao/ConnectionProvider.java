/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Awsom
 */
public class ConnectionProvider {
    public static final String username = "root";
    public static final String password = "PeanutsBomberMaggie2010";
    public static final String url = "jdbc:mysql://localhost/blue_screen_diner";
    public static Connection con = null;
    
    public static Connection getCon() throws SQLException{
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(url, username, password);
            return con;
        } catch (Exception ex){
            JOptionPane.showMessageDialog(null, ""+ex, "", JOptionPane.WARNING_MESSAGE);
        }
        return con;
    }

}

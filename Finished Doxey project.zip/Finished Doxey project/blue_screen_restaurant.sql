create database blue_screen_restaurant;
use blue_screen_restaurant;

CREATE TABLE Admin(
	id int NOT NULL AUTO_INCREMENT,
    email varchar(200),
    password varchar(20),
    PRIMARY KEY (id)
);

CREATE TABLE Employee(
	emid int NOT NULL,
    emname varchar(100),
    ememail varchar(100),
    empassword varchar(100),
    emphone varchar(15),
    emaddress1 text,
    emaddress2 text,
    PRIMARY KEY (emname)
);

CREATE TABLE Users(
	id int NOT NULL AUTO_INCREMENT,
    user_name varchar(200),
    email varchar(100),
    password varchar(100),
    phone_number varchar(15),
    security_question text,
    answer text,
    address varchar(200),
    PRIMARY KEY (id)
);

CREATE TABLE Category(
	id int NOT NULL AUTO_INCREMENT,
    category varchar(200),
    PRIMARY KEY (id)
);

CREATE TABLE Product(
	id int NOT NULL AUTO_INCREMENT,
    name varchar(100),
    category varchar(200),
    price double,
    PRIMARY KEY (id)
);

CREATE TABLE Reservation(
res_id int NOT NULL AUTO_INCREMENT,
user_id int,
table_num int,
reservation datetime DEFAULT NULL,
PRIMARY KEY(res_id),
FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE Orders(
order_id int NOT NULL AUTO_INCREMENT,
user_id int,
product_id int,
picked_up boolean not null default 0,
PRIMARY KEY (order_id),
FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY (product_id) REFERENCES Product(product_id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE Bill(
id int AUTO_INCREMENT PRIMARY KEY,
name varchar(200),
phone_number varchar(200),
email varchar(200),
date varchar(50),
createdBy varchar(200)
);

CREATE TABLE blue_screen_restaurant.Rating(
rating_id int NOT NULL AUTO_INCREMENT,
user_email varchar(200),
experience_rating varchar(10),
comments varchar(255),
PRIMARY KEY (rating_id)
);

INSERT INTO blue_screen_restaurant.Users
VALUES (1, 'George Salayka', 'GSalayka@nyit.edu', 'BesProfessor', '51698562036','What is your favorite color?', 'Black', 'Test Street 100');

INSERT INTO blue_screen_restaurant.Users
VALUES(2, 'JohnSmith', 'JohnSmith@gmail.com', 'JohnSmithisCool247', '51944811818', 'What is your family name?', 'Smith', 'Tester Stree 200');

INSERT INTO blue_screen_restaurant.Users
VALUES(3, 'Bob', 'Bob@gmail.com', 'BobisCoool', '51944811818', 'What was your first car?', 'Tayota', 'Bob st 18999, NY');

INSERT INTO blue_screen_restaurant.Admin
VALUES (1, 'kaebly01@nyit.edu', 'ChocolateBear');

INSERT INTO blue_screen_restaurant.Admin
VALUES (2, 'cjsommers@nyit.edu', 'BlueScreenMaker');

INSERT INTO blue_screen_restaurant.admin
VALUES (3, 'ncivil@nyit.edu', 'FlammingPhoenix');
 
INSERT INTO blue_screen_restaurant.Employee
VALUES (1, 'Fdemarco@nyi.edu', 'SleepyChild',  '51679826793', 'Test Street 1000, NY');

INSERT INTO blue_screen_restaurant.Employee
VALUES (2, 'Caroline', 'Caroline@gmail.com', 'CarolineIsDumb', '51689517898', 'Carol st 22322, NJ');

INSERT INTO blue_screen_restaurant.Category
VALUES (1, 'Burger');

INSERT INTO blue_screen_restaurant.Category
VALUES (2, 'Salad');

INSERT INTO blue_screen_restaurant.Category
VALUES (3, 'Soup');

INSERT INTO blue_screen_restaurant.Category
VALUES (4, 'Cold Drink');

INSERT INTO blue_screen_restaurant.Category
VALUES (5, 'hot Drink');

INSERT INTO blue_screen_restaurant.Category
VALUES (6, 'Smoothie');

INSERT INTO blue_screen_restaurant.Category
VALUES (7, 'sandwhich');

INSERT INTO blue_screen_restaurant.Product
VALUES (1, 'Cheese Burger', 'Burger', 2.5);

INSERT INTO blue_screen_restaurant.Product
VALUES (2, 'Grilled Cheese' ,'sandwhich',1.5);


DROP TABLE blue_screen_restaurant.Rating;
DROP TABLE blue_screen_restaurant.Reservation;
DROP TABLE blue_screen_restaurant.Orders;
DROP TABLE blue_screen_restaurant.Product;
DROP TABLE blue_screen_restaurant.Category;
DROP TABLE blue_screen_restaurant.Users;
DROP TABLE blue_screen_restaurant.Admin;
DROP TABLE blue_screen_restaurant.Employee;
